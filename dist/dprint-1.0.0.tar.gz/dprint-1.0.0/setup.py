from distutils.core import setup

setup(
        name    = 'dprint', 
        version = '1.0.0', 
        py_modules = ['dprint'], 
        author = 'hieonn', 
        author_email = '',
        url = '',
        description = 'A simple debug print', 
        )